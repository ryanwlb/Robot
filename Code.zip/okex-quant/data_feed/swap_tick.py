import asyncio
import websockets
import json
import requests
import dateutil.parser as dp
import hmac
import base64
import zlib
import pandas as pd
from queue import Empty, Queue
from threading import Thread
from tzlocal import get_localzone
from datetime import datetime


class DataFeed:
    def __init__(self, **setting):
        self.symbol = setting.get('symbol')
        self.api_key = setting.get('api_key')
        self.secret_key = setting.get('secret_key')
        self.passphrase = setting.get('passphrase')
        self.url = 'wss://real.okex.com:10442/ws/v3'
        self.queue = Queue()
        self.thread = Thread(target=self.save_tick)
        self.local_dir = 'C:\\tick\\EOS-USD-SWAP.csv'

    def save_tick(self):
        while True:
            try:
                depth = self.queue.get(block=True, timeout=1)
                depth.to_csv(self.local_dir, mode='a', header=None)
            except Empty:
                pass

    def start(self):
        self.thread.start()
        depth_channle_name = 'swap/candle60s:' + self.symbol
        channels = [depth_channle_name]
        asyncio.get_event_loop().run_until_complete(self.connect(channels))

    async def connect(self, channels):
        async with websockets.connect(self.url) as websocket:
            tempstamp = str(self.server_timestamp())
            login_str = self.login_params(str(tempstamp))
            await websocket.send(login_str)

            login_res = await websocket.recv()
            print(f'{self.inflate(login_res)}')

            sub_param = {"op": "subscribe", "args": channels}
            sub_str = json.dumps(sub_param)
            await  websocket.send(sub_str)
            print(f"send: {sub_str}")

            while True:
                res = await websocket.recv()
                res = self.inflate(res)
                res = eval(res)
                if res.get('table') is not None and res.get('table') == 'swap/candle60s':
                    ticker = pd.DataFrame(res.get('data')[0]['candle']).T
                    ticker.rename(columns={0:'time',1:'open',2:'high',3:'low',4:'close',5:'volume_zhang',6:'volume_b'},inplace=True)
                    time = ticker.loc[0,'time']
                    time = pd.to_datetime(time).tz_convert("Asia/ShangHai")
                    ticker.loc[0,'time'] = time
                    print(f'{datetime.now()} get bars with time {time}')
                    self.queue.put(ticker)

    def get_server_time(self):
        url = "http://www.okex.com/api/general/v3/time"
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()['iso']
        else:
            return ""

    def server_timestamp(self):
        server_time = self.get_server_time()
        parsed_t = dp.parse(server_time)
        timestamp = parsed_t.timestamp()
        return timestamp

    def login_params(self, timestamp):
        message = timestamp + 'GET' + '/users/self/verify'
        mac = hmac.new(bytes(self.secret_key, encoding='utf8'), bytes(message, encoding='utf-8'), digestmod='sha256')
        d = mac.digest()
        sign = base64.b64encode(d)

        login_param = {"op": "login", "args": [self.api_key, self.passphrase, timestamp, sign.decode("utf-8")]}
        login_str = json.dumps(login_param)
        return login_str

    def inflate(self, data):
        decompress = zlib.decompressobj(
            -zlib.MAX_WBITS  # see above
        )
        inflated = decompress.decompress(data)
        inflated += decompress.flush()
        return inflated


if __name__ == '__main__':
    setting = {
        'symbol': 'EOS-USD-SWAP',
        'api_key': '0ec59551-1aab-4070-b55f-dbbb5c2372ad',
        'secret_key': '5118C891F3CD294B1E934D2E7ED26C5E',
        'passphrase': 'zhang123',
        'limit': 500000,
        'tick_bias': 1,
        'leverage': 20,
    }
    depth = DataFeed(**setting)
    depth.start()