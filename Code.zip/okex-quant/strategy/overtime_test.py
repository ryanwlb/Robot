import asyncio
import websockets
import json
import requests
import dateutil.parser as dp
import hmac
import base64
import zlib

def inflate(data):
    decompress = zlib.decompressobj(
            -zlib.MAX_WBITS  # see above
    )
    inflated = decompress.decompress(data)
    inflated += decompress.flush()
    return inflated

url = 'wss://real.okex.com:10442/ws/v3'

with websockets.connect(url) as websocket:

    websocket.send('ping')
    while True:
        res = websocket.recv()
        res = inflate(res)
        print(res)

# asyncio.get_event_loop().run_until_complete(overtime())