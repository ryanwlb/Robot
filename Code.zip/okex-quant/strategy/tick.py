from strategy.base_strategy import Strategy
from strategy.base_strategy import OrderStatus, OrderDirection
import pandas as pd

class Tick(Strategy):

    def __init__(self, symbol, api_key, secret_key, passphrase, limit):
        Strategy.__init__(self, symbol, api_key, secret_key, passphrase, limit)

    def on_get_tick(self, tick):
        file = 'C:\\tick\\' + self.symbol + '.csv'
        tick.to_csv(file, mode='a')


if __name__ == '__main__':
    strategy = Tick(symbol='EOS-USD-SWAP', api_key='0ec59551-1aab-4070-b55f-dbbb5c2372ad',
                        secret_key='5118C891F3CD294B1E934D2E7ED26C5E', passphrase='zhang123', limit=5000)
    strategy.start_tick(type='swap/ticker')