import sys
sys.path.append('C:\\Code\\okex-quant')
from strategy.base_strategy import Strategy
from strategy.base_strategy import OrderStatus, OrderDirection, PositionDirection
import numpy as np
from tzlocal import get_localzone
from datetime import datetime

class BigOrder(Strategy):

    def __init__(self, **setting):
        Strategy.__init__(self, **setting)
        self.tick_bias = setting.get('tick_bias',1)
        self.lot = setting.get('lot',1)
        self.order_volume = {'long': 0, 'short': 0}
        self.percentage = setting.get('percentage')
        self.stoploss = setting.get('stoploss')
        self.start_trailing_profit = setting.get('start_trailing_profit')
        self.trailing_step = setting.get('trailing_step')
        self.facevalue = setting.get('facevalue')
        self.max_long_pnl = 0
        self.max_short_pnl = 0
        self.round = int(abs(np.log10(self.tick_size)))

    def order_book_analysis(self,ask_df, bid_df):
        # 处理深度数据，判断是否有大单，并返回大单价格以及单量
        ask_huge = ask_df[ask_df['ask_volume'] >= self.limit]
        bid_huge = bid_df[bid_df['bid_volume'] >= self.limit]
        if ask_huge.__len__() > 0 and bid_huge.__len__() > 0:
            max_ask_volume = ask_huge['ask_volume'].max()
            max_bid_volume = bid_huge['bid_volume'].max()
            if max_ask_volume > max_bid_volume:
                res = {
                    'type': 'ask',
                    'optimal_price': (ask_huge.loc[ask_huge['ask_volume'] == max_ask_volume,'ask_price'].values[0] - self.tick_bias * self.tick_size).__round__(self.round),
                    'optimal_volume': max_ask_volume
                }
            else:
                res = {
                    'type': 'bid',
                    'optimal_price': (bid_huge.loc[bid_huge['bid_volume'] == max_bid_volume, 'bid_price'].values[0] + self.tick_bias * self.tick_size).__round__(self.round),
                    'optimal_volume': max_bid_volume
                }
        elif ask_huge.__len__() > 0 and bid_huge.__len__() == 0:
            max_ask_volume = ask_huge['ask_volume'].max()
            res = {
                'type': 'ask',
                'optimal_price': (ask_huge.loc[ask_huge[ 'ask_volume'] == max_ask_volume, 'ask_price'].values[0] - self.tick_bias * self.tick_size).__round__(self.round),
                'optimal_volume': max_ask_volume
            }
        elif ask_huge.__len__() == 0 and bid_huge.__len__() > 0:
            max_bid_volume = bid_huge['bid_volume'].max()
            res = {
                'type': 'bid',
                'optimal_price': (bid_huge.loc[bid_huge[ 'bid_volume'] == max_bid_volume, 'bid_price'].values[0] + self.tick_bias * self.tick_size).__round__(self.round),
                'optimal_volume': max_bid_volume
            }
        else:
            res = None
        return res

    def update_order_info(self):
        waiting_order = self.get_order(OrderStatus.waiting.value)
        if waiting_order is None:
            pass
        else:
            if waiting_order.__len__() > 0:
                data = waiting_order[0]
                if data['type'] == str(OrderDirection.open_short.value):
                    self.short_limit_order_price = float(data['price'])
                    self.short_limit_order_id = data['order_id']
                if data['type'] == str(OrderDirection.open_long.value):
                    self.long_limit_order_price = float(data['price'])
                    self.long_limit_order_id = data['order_id']
            if waiting_order.__len__() == 0:
                self.long_limit_order_price = 0
                self.long_limit_order_id = ''
                self.short_limit_order_price = 0
                self.short_limit_order_id = ''

    def _handle_no_position_no_limit_situation(self, depth_res, time):
        # 处理没有持仓 也没有挂单的情况
        # 只需判断是否需要挂单即可
        if depth_res['type'] == 'bid':
            open_short_res = self.send_order(direction=OrderDirection.open_short.value,
                                             price=depth_res['optimal_price'],
                                             size=self.lot,
                                             leverage=self.leverage)
            if open_short_res is not None:
                self.order_volume.update({'short': depth_res['optimal_volume']})
                self.logger.info(f'{self.symbol}{time} 初次挂卖单成功 价：{depth_res["optimal_price"]} 量：{depth_res["optimal_volume"]}')
            else:
                self.logger.info(f'{self.symbol}{time} 初次挂卖单失败')

        if depth_res['type'] == 'ask':
            open_long_res = self.send_order(direction=OrderDirection.open_long.value,
                                            price=depth_res['optimal_price'],
                                            size=self.lot,
                                            leverage=self.leverage)
            if open_long_res is not None:
                self.order_volume.update({'long': depth_res['optimal_volume']})
                self.logger.info(f'{self.symbol}{time} 初次挂买单成功 价：{depth_res["optimal_price"]} 量：{depth_res["optimal_volume"]}')
            else:
                self.logger.info(f'{self.symbol}{time} 初次挂买单失败')

    def _handle_no_position_long_limit_situation(self, depth_res, time):
            # 处理无持仓 有多方挂单情况
            if depth_res is None:
                # 大单撤单  平仓
                cancel_long_res = self.cancel_order(self.long_limit_order_id, OrderDirection.open_long.value)
                if cancel_long_res is not None:
                    self.logger.info(f'{self.symbol}{time} 大单撤单 撤买单成功')
                    self.order_volume.update({'long': 0})
                    self.long_limit_order_id = ''
                    self.long_limit_order_price = 0
                else:
                    self.logger.info(f'{self.symbol}{time} 大单撤单 撤买单失败')
            else:
                if depth_res['type'] == 'bid':
                    # 大单方向改变
                    cancel_long_res = self.cancel_order(self.long_limit_order_id, OrderDirection.open_long.value)
                    if cancel_long_res is not None:
                        self.logger.info(f'{self.symbol}{time} 大单方向改变 撤买单成功')
                        self.order_volume.update({'long': 0})
                        self.long_limit_order_price = 0
                        self.long_limit_order_id = ''
                        open_short_res = self.send_order(direction=OrderDirection.open_short.value,
                                                         price=depth_res['optimal_price'],
                                                         size=self.lot,
                                                         leverage=self.leverage)
                        if open_short_res is not None:
                            self.order_volume.update({'short': depth_res['optimal_volume']})
                            self.logger.info(f'{self.symbol}{time} 大单方向改变 开卖单成功')
                        else:
                            self.logger.info(f'{self.symbol}{time} 大单方向改变 开卖单失败')
                    else:
                        self.logger.info(f'{self.symbol}{time} 大单方向改变 撤买单失败')
                else:
                    # 大单方向没改变 需判断价格是否改变
                    if self.long_limit_order_price != depth_res['optimal_price']:
                        cancel_long_res = self.cancel_order(self.long_limit_order_id, OrderDirection.open_long.value)
                        if cancel_long_res is not None:
                            self.logger.info(f'{self.symbol}{time} 大单价格改变 由{self.long_limit_order_price}变为{depth_res["optimal_price"]} 撤买单成功')
                            self.order_volume.update({'long': 0})
                            self.long_limit_order_price = 0
                            self.long_limit_order_id = ''
                            open_long_res = self.send_order(direction=OrderDirection.open_long.value,
                                                            price=depth_res['optimal_price'],
                                                            size=self.lot,
                                                            leverage=self.leverage)
                            if open_long_res is not None:
                                self.order_volume.update({'long': depth_res['optimal_volume']})
                                self.logger.info(f'{self.symbol}{time} 大单价格改变 开买单成功')
                            else:
                                self.logger.info(f'{self.symbol}{time} 大单价格改变 开买单失败')
                        else:
                            self.logger.info(f'{self.symbol}{time} 大单价格改变 撤买单失败')

    def _handle_no_position_short_limit_situation(self, depth_res, time):
        # 处理无持仓 有空向挂单
        if depth_res is None:
            cancel_short_res = self.cancel_order(self.long_limit_order_id, OrderDirection.open_short.value)
            if cancel_short_res is not None:
                self.logger.info(f'{self.symbol}{time} 大单撤单 撤卖单成功')
                self.order_volume.update({'short': 0})
                self.short_limit_order_id = ''
                self.short_limit_order_price = 0
            else:
                self.logger.info(f'{self.symbol}{time} 大单撤单 撤卖单失败')
        else:
            if depth_res['type'] == 'ask':
                # 大单方向改变
                cancel_short_res = self.cancel_order(self.long_limit_order_id, OrderDirection.open_short.value)
                if cancel_short_res is not None:
                    self.logger.info(f'{self.symbol}{time} 大单方向改变 撤卖单成功')
                    self.order_volume.update({'short': 0})
                    self.short_limit_order_id = ''
                    self.short_limit_order_price = 0
                    open_long_res = self.send_order(direction=OrderDirection.open_long.value,
                                                     price=depth_res['optimal_price'],
                                                     size=self.lot,
                                                     leverage=self.leverage)
                    if open_long_res is not None:
                        self.order_volume.update({'long': depth_res['optimal_volume']})
                        self.logger.info(f'{self.symbol}{time} 大单方向改变 开买单成功')
                    else:
                        self.logger.info(f'{self.symbol}{time} 大单方向改变 开买单失败')
                else:
                    self.logger.info(f'{self.symbol}{time} 大单方向改变 撤卖单失败')
            else:
                # 大单方向没改变 需判断价格是否改变
                if self.short_limit_order_price != depth_res['optimal_price']:
                    cancel_short_res = self.cancel_order(self.long_limit_order_id, OrderDirection.open_short.value)
                    if cancel_short_res is not None:
                        self.logger.info(f'{self.symbol}{time} 大单价格改变 由{self.short_limit_order_price}变为{depth_res["optimal_price"]} 撤卖单成功')
                        self.order_volume.update({'short': 0})
                        self.short_limit_order_id = ''
                        self.short_limit_order_price = 0
                        open_short_res = self.send_order(direction=OrderDirection.open_short.value,
                                                        price=depth_res['optimal_price'],
                                                        size=self.lot,
                                                        leverage=self.leverage)
                        if open_short_res is not None:
                            self.order_volume.update({'short': depth_res['optimal_volume']})
                            self.logger.info(f'{self.symbol}{time} 大单价格改变 开卖单成功')
                        else:
                            self.logger.info(f'{self.symbol}{time} 大单价格改变 开卖单失败')
                    else:
                        self.logger.info(f'{self.symbol}{time} 大单价格改变 撤卖单失败')

    def _handle_long_position_situation(self, ask_df, bid_df, time):
        # 处理有多向持仓的情况，判断止损，移动止损，以及大单被吃的情况
        profit = ((((ask_df.loc[0, 'ask_price'] - self.long_avg_cost) / self.long_avg_cost) * self.facevalue)/self.long_avg_cost)*self.lot
        margin = ((self.facevalue/self.long_avg_cost)/self.leverage)*self.lot
        win_rate = profit/margin
        self.max_long_pnl = max(win_rate, self.max_long_pnl)
        self.logger.info(f'{self.symbol}{time} 收益{profit} 多单收益率{win_rate} 最大收益率{self.max_long_pnl}')
        now_volume_ask = ask_df.loc[ask_df['ask_price'] == self.long_avg_cost, 'ask_volume']
        now_volume_bid = bid_df.loc[bid_df['bid_price'] == self.long_avg_cost, 'bid_volume']
        if now_volume_ask is not None and now_volume_ask.__len__() > 0:
            now_volume = now_volume_ask.values[0]
        elif now_volume_bid is not None and now_volume_bid.__len__() > 0:
            now_volume = now_volume_bid.values[0]
        else:
            now_volume = 0

        # 判断是否止损
        if win_rate <= -self.stoploss:
            close_res = self.close_order(direction=PositionDirection.long.value)
            if close_res is not None:
                self.logger.info(f'{self.symbol}{time}多单止损，平仓成功 收益{win_rate}')
                self.order_volume.update({'long': 0})
                self.max_long_pnl = 0
                return
            else:
                self.logger.info(f'{self.symbol}{time} 多单止损，平仓失败')
        # 判断是否追踪止损
        if (win_rate <= (self.max_long_pnl * self.trailing_step)) and self.max_long_pnl >= self.start_trailing_profit:
            close_res = self.close_order(direction=PositionDirection.long.value)
            if close_res is not None:
                self.logger.info(f'{self.symbol}{time}多单追踪止损，平仓成功 收益{win_rate}')
                self.order_volume.update({'long': 0})
                self.max_long_pnl = 0
                return
            else:
                self.logger.info(f'{self.symbol}{time} 多单追踪止损，平仓失败 收益{win_rate}')
        # 判断大单是否被吃
        # if self.order_volume['long']!=0:
        #     if now_volume is not None and (now_volume / self.order_volume['long']) <= self.percentage and win_rate>=0.01:
        #         close_res = self.close_order(direction=PositionDirection.long.value)
        #         if close_res is not None:
        #             self.logger.info(f'{self.symbol}{time}多单大单被吃 原量：{self.order_volume["long"]} 现量{now_volume}，平仓成功 收益{win_rate}')
        #             self.order_volume.update({'long': 0})
        #             self.max_long_pnl = 0
        #             return
        #         else:
        #             self.logger.info(f'{self.symbol}{time} 多单大单被吃，平仓失败')

    def _handle_short_position_situation(self, ask_df, bid_df, time):
        profit = ((((self.short_avg_cost-bid_df['bid_price'].max())/self.short_avg_cost)*self.facevalue)/self.short_avg_cost)*self.lot
        margin = ((self.facevalue / self.short_avg_cost) / self.leverage) * self.lot
        win_rate = profit/margin
        self.max_short_pnl = max(win_rate, self.max_short_pnl)
        self.logger.info(f'{self.symbol}{time} 收益{profit} 空单收益率{win_rate} 最大收益率{self.max_short_pnl}')
        now_volume_ask = ask_df.loc[ask_df['ask_price'] == self.short_avg_cost, 'ask_volume']
        now_volume_bid = bid_df.loc[bid_df['bid_price'] == self.short_avg_cost, 'bid_volume']
        if now_volume_ask is not None and now_volume_ask.__len__() > 0:
            now_volume = now_volume_ask.values[0]
        elif now_volume_bid is not None and now_volume_bid.__len__() > 0:
            now_volume = now_volume_bid.values[0]
        else:
            now_volume = 0

        # 判断是否止损
        if win_rate <= -self.stoploss:
            close_res = self.close_order(direction=PositionDirection.short.value)
            if close_res is not None:
                self.logger.info(f'{self.symbol}{time} 空单止损，平仓成功 收益{win_rate}')
                self.order_volume.update({'short': 0})
                self.max_short_pnl = 0
                return
            else:
                self.logger.info(f'{self.symbol}{time} 空单止损，平仓失败')
                # 判断是否追踪止损
        if (win_rate <= (self.max_short_pnl * self.trailing_step)) and self.max_short_pnl >= self.start_trailing_profit:
            close_res = self.close_order(direction=PositionDirection.short.value)
            if close_res is not None:
                self.logger.info(f'{self.symbol}{time} 空单追踪止损，平仓成功 收益{win_rate}')
                self.order_volume.update({'short': 0})
                self.max_short_pnl = 0
                return
            else:
                self.logger.info(f'{self.symbol}{time} 多单追踪止损，平仓失败')
        # 判断大单是否被吃
        # if self.order_volume['short']!=0:
        #     if now_volume is not None and (now_volume / self.order_volume['short']) <= self.percentage and win_rate>=0.01:
        #         close_res = self.close_order(direction=PositionDirection.short.value)
        #         if close_res is not None:
        #             self.logger.info(f'{self.symbol}{time} 空单大单被吃 原量：{self.order_volume["short"]} 现量{now_volume}，平仓成功 收益{win_rate}')
        #             self.order_volume.update({'short': 0})
        #             self.max_short_pnl = 0
        #             return
        #         else:
        #             self.logger.info(f'{self.symbol}{time} 空单大单被吃，平仓失败')

    def on_order_book(self, ask_df, bid_df, time):
        self.update_order_info()
        depth_res = self.order_book_analysis(ask_df=ask_df, bid_df=bid_df)
        # self.logger.info(f'{self.symbol}{time} order book res:{depth_res}')
        # 如果没有持仓
        if self.long_qty == 0 and self.short_qty == 0:
            if self.long_limit_order_price == 0 and self.short_limit_order_price == 0 and depth_res is not None:
                # 如果双向都没有挂单
                self._handle_no_position_no_limit_situation(depth_res, time)

            if self.long_limit_order_price != 0:
                # 如果现有挂单是买方向
                self._handle_no_position_long_limit_situation(depth_res, time)

            if self.short_limit_order_price != 0:
                # 如果现有挂单是卖方向
                self._handle_no_position_short_limit_situation(depth_res, time)
        if self.long_qty > 0:
            # 有多头持仓
            self._handle_long_position_situation(ask_df, bid_df, time)
        if self.short_qty > 0:
            # 有空头持仓
            self._handle_short_position_situation(ask_df, bid_df,time)
        # tz = get_localzone()
        # now = tz.localize(datetime.now())
        # delta = (now-time)
        # self.logger.info(f'delay is {delta}')

if __name__ == '__main__':
    # setting = {
    #     'symbol': 'BTC-USD-190927',
    #     'api_key': '0ec59551-1aab-4070-b55f-dbbb5c2372ad',
    #     'secret_key': '5118C891F3CD294B1E934D2E7ED26C5E',
    #     'passphrase': 'zhang123',
    #     'limit': 10000,
    #     'tick_bias': 1,
    #     'leverage': 25,
    #     'dalay': 2,
    #     'lot': 1,
    #     'stoploss': 0.05, # 止损百分比
    #     'start_trailing_profit': 0.08, #开始移动止损盈利百分比
    #     'trailing_step': 0.7, # 最大收益的回撤 最大收益百分比的
    #     'percentage': 0.7, # 大单单量被吃了70%平仓
    #     'facevalue': 100,
    #     'log_dir': 'C:\\btc.log'
    #     }
    setting = {
        'symbol': 'EOS-USD-190927',
        'api_key': '0ec59551-1aab-4070-b55f-dbbb5c2372ad',
        'secret_key': '5118C891F3CD294B1E934D2E7ED26C5E',
        'passphrase': 'zhang123',
        'limit': 50000,
        'tick_bias': 1,
        'leverage': 20,
        'dalay': 2,
        'lot': 1,
        'stoploss': 0.05, # 止损百分比
        'start_trailing_profit': 0.08, #开始移动止损盈利百分比
        'trailing_step': 0.7, # 最大收益的回撤 最大收益百分比的
        'percentage': 0.7, # 大单单量被吃了70%平仓
        'facevalue': 10,
        'log_dir': 'C:\\eos.log'
    }
    strategy = BigOrder(**setting)
    strategy.start()
