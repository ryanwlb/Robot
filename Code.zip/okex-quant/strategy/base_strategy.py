import sys
sys.path.append('C:\\Code\\open-api-v3-sdk\\okex-python-sdk-api')
import asyncio
import websockets
import json
import requests
import dateutil.parser as dp
import hmac
import base64
import zlib
import pandas as pd
from datetime import datetime
from queue import Empty, Queue, LifoQueue, PriorityQueue
from threading import Thread
from tzlocal import get_localzone
from okex.futures_api import FutureAPI
from enum import Enum
from time import sleep
from datetime import datetime
import logging
# logging.basicConfig(level=logging.INFO, format='%(asctime)s -- %(levelname)s: %(message)s')



class OrderStatus(Enum):
    fail = -2
    cancel_done = -1
    waiting = 0
    part_done = 1
    all_done = 2
    in_order = 3
    in_cancel = 4
    undone = 5
    done = 6


class OrderDirection(Enum):
    open_long = 1
    open_short = 2
    close_long = 3
    close_short = 4


class PositionDirection(Enum):
    long = 'long'
    short = 'short'


class Strategy:
    def __init__(self, **setting):
        self.symbol = setting.get('symbol')
        self.api_key = setting.get('api_key')
        self.secret_key = setting.get('secret_key')
        self.passphrase = setting.get('passphrase')
        self.limit = setting.get('limit', 500000)
        self.leverage = setting.get('leverage', 10)
        self.delay = setting.get('delay', 2)
        self.log_dir = setting.get('log_dir')
        self.url = 'wss://real.okex.com:10442/ws/v3'

        self.queue = LifoQueue()
        self.thread = Thread(target=self.on_depth)

        self.delay = 3
        self.client_id = 'vaferasdffae8'
        self.future_api = FutureAPI(self.api_key, self.secret_key, self.passphrase, True)

        self.order = pd.DataFrame()

        self.tick_size = self._get_tick_size()

        self.sleep_time = 0.5

        # 是否有挂单 从webscoket更新

        self.short_limit_order_price = 0.0
        self.short_limit_order_id = ''
        self.long_limit_order_price = 0.0
        self.long_limit_order_id = ''
        # 持仓单信息
        self.long_qty = 0
        self.long_avg_cost = 0
        self.long_pnl_ratio = 0
        self.short_qty = 0
        self.short_avg_cost = 0
        self.short_pnl_ratio = 0

        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(level=logging.INFO)
        handler = logging.FileHandler(self.log_dir)
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)

        console = logging.StreamHandler()
        console.setLevel(logging.INFO)

        self.logger.addHandler(handler)
        self.logger.addHandler(console)

    def _get_tick_size(self):
        info = self.future_api.get_products()
        df = pd.DataFrame(info)
        try:
            return df.loc[df['instrument_id'] == self.symbol, 'tick_size'].astype(float).values[0]
        except Exception as e:
            logging.warning(e)

    # def get_position(self):
    #     try:
    #         position = self.future_api.get_specific_position(self.symbol)
    #         if position['result']:
    #             return pd.DataFrame(position['holding'])
    #         else:
    #             return []
    #     except Exception as e:
    #         print(e)
    #         return None

    def get_order(self, status=OrderStatus.waiting):
        try:
            orders = self.future_api.get_order_list(status=status, instrument_id=self.symbol,froms=0,to=1,limit=100)
            if orders['result']:
                return orders['order_info']
            else:
                return None
        except Exception as e:
            logging.warning(e)
            return None

    def send_order(self, direction, price, size, match_price=0, leverage=5):
        try:
            result = self.future_api.take_order(self.client_id, self.symbol, direction, price, size, match_price,
                                                leverage)
            if result['order_id'] != -1:
                return result['order_id']
            else:
                logging.warning(f'下单错误 {result["error_message"]}')
                return None
        except Exception as e:
            logging.warning(e)
            return None

    def close_order(self, direction):
        try:
            result = self.future_api.close_position(self.symbol, direction)
            if result['result'] == True:
                if direction == PositionDirection.long.value:
                    if self.long_avg_cost != 0:
                        self.long_avg_cost = 0
                    if self.long_qty != 0:
                        self.long_qty = 0
                if direction == PositionDirection.short.value:
                    if self.short_avg_cost!=0:
                        self.short_avg_cost = 0
                    if self.short_qty!=0:
                        self.short_qty = 0

                return 1
            else:
                self.logger.warning(f'{self.symbol}平单失败 原因：{result["error_message"]}')
                return None
        except Exception as e:
            logging.warning(e)
            return None

    def cancel_order(self, order_id, direction):
        try:
            result = self.future_api.revoke_order(self.symbol, order_id, self.client_id)
            if result['result'] == True:
                return result['order_id']
            else:
                self.logger.warning(f'{self.symbol}撤单失败 订单{result["order_id"]} 不存在')
                return None
        except Exception as e:
            self.logger.warning(e)
            return None

    def on_depth(self):
        while True:
            try:
                depth = self.queue.get(block=True, timeout=1)
                self.on_order_book(depth['ask'], depth['bid'], depth['time'])
            except Empty:
                pass

    def on_order_book(self, ask_df, bid_df, time):
        pass


    def start(self):
        self.thread.start()
        depth_channle_name = 'futures/depth:' + self.symbol
        position_channel_name = 'futures/position:' + self.symbol
        order_channel_name = 'futures/order:' + self.symbol
        channels = [position_channel_name, depth_channle_name]
        asyncio.get_event_loop().run_until_complete(self.connect(channels))

    async def connect(self, channels):
        async with websockets.connect(self.url) as websocket:
            tempstamp = str(self.server_timestamp())
            login_str = self.login_params(str(tempstamp))
            await websocket.send(login_str)

            login_res = await websocket.recv()
            self.logger.info(f'{self.symbol}账号登录结果：{self.inflate(login_res)}')

            sub_param = {"op": "subscribe", "args": channels}
            sub_str = json.dumps(sub_param)
            await  websocket.send(sub_str)
            # print(f"send: {sub_str}")

            ask = pd.DataFrame()
            bid = pd.DataFrame()
            while True:
                res = await websocket.recv()
                res = self.inflate(res)
                res = eval(res)
                if res.get('table') is not None and res.get('table') == 'futures/position':
                    position_data = res.get('data')[0]
                    if position_data['instrument_id'] == self.symbol:
                        self.long_pnl_ratio = float(position_data['long_pnl_ratio'])
                        self.long_qty = float(position_data['long_qty'])
                        self.long_avg_cost = float(position_data['long_avg_cost'])
                        self.short_pnl_ratio = float(position_data['short_pnl_ratio'])
                        self.short_qty = float(position_data['short_qty'])
                        self.short_avg_cost = float(position_data['short_avg_cost'])
                    # self.lock.release()
                if res.get('table') is not None and res.get('table') == 'futures/order':
                    data = res.get('data', None)
                    data = data[0] if data is not None else None
                    if data is not None and data['status'] == str(OrderStatus.waiting.value) and data['type'] == str(OrderDirection.open_short.value):
                        # self.lock.acquire()
                        self.short_limit_order_id = data['order_id']
                        self.short_limit_order_price = float(data['price'])
                        # self.lock.release()
                    if data is not None and data['status'] == str(OrderStatus.waiting.value) and data['type'] == str(OrderDirection.open_long.value):
                        # self.lock.acquire()
                        self.long_limit_order_id = data['order_id']
                        self.long_limit_order_price = float(data['price'])
                        # self.lock.release()
                    if data is not None and data['status'] == str(OrderStatus.cancel_done.value) and data['type'] == str( OrderDirection.open_short.value):
                        # self.lock.acquire()
                        self.short_limit_order_id = ''
                        self.short_limit_order_price = 0
                        # self.lock.release()
                    if data is not None and data['status'] == str(OrderStatus.cancel_done.value) and data['type'] == str( OrderDirection.open_long.value):
                        # self.lock.acquire()
                        self.long_limit_order_id = ''
                        self.long_limit_order_price = 0
                        # self.lock.release()

                if res.get('table') is not None and res.get('table') == 'futures/depth':
                    if res['action'] == 'partial':
                        if res['data'][0]['instrument_id'] == self.symbol:
                            ask = pd.DataFrame(res['data'][0]['asks'],
                                               columns=['ask_price', 'ask_volume', 'ask_qp', 'ask_n']).astype(float)
                            bid = pd.DataFrame(res['data'][0]['bids'],
                                               columns=['bid_price', 'bid_volume', 'bid_qp', 'bid_n']).astype(float)
                    if res['action'] == 'update':
                        if res['data'][0]['instrument_id'] == self.symbol:
                            ask_new = pd.DataFrame(res['data'][0]['asks'],
                                                   columns=['ask_price', 'ask_volume', 'ask_qp', 'ask_n']).astype(float)
                            bid_new = pd.DataFrame(res['data'][0]['bids'],
                                                   columns=['bid_price', 'bid_volume', 'bid_qp', 'bid_n']).astype(float)
                            ask, bid = self.handle_depth(ask, bid, ask_new, bid_new)
                    time = res['data'][0]['timestamp']
                    time = pd.to_datetime(time).tz_convert("Asia/ShangHai")

                    # logging.info(f'接口时间{time}   卖一价 {ask.loc[0,"ask_price"]}  系统时间  {datetime.now()}')
                    self.send_data(ask, bid,time)
                    # print(f'接口时间{time}   卖一价 {ask.loc[0, "ask_price"]}  系统时间  {datetime.now()}')
                    # tz = get_localzone()
                    # now = tz.localize(datetime.now())
                    # delta = (now - time)
                    # if delta.seconds >= self.delay:
                    #     print(f'{now}延迟预警，清空队列 长度{self.queue.qsize()}')
                    #     self.queue.queue.clear()

    def handle_depth(self, ask, bid, ask_new, bid_new):
        # 增量数据 价格在原数据中，且交易量为0 ，删除该档深度
        # 增量数据 价格在原数据中，且交易量不为0， 替换原数据
        # 增量数据 价格不在原数据中，排序取200个
        ask_merge = ask.merge(ask_new, on='ask_price', right_index=True, how='right')
        ask_merge_update = ask_merge.dropna()
        ask_merge_delete = ask_merge[ask_merge['ask_volume_y'] == 0]
        ask_merge_update = ask_merge_update[ask_merge_update['ask_volume_y'] > 0]
        ask_merge_insert = ask_merge.append(ask_merge_update).drop_duplicates(keep=False)
        ask_merge_insert = ask_merge_insert[ask_merge_insert['ask_volume_y'] > 0]
        # delete
        if ask_merge_delete.__len__() > 0:
            ask = ask.drop(ask_merge_delete.index)
        # update
        if ask_merge_update.__len__() > 0:
            ask.loc[ask.index.isin(ask_merge_update.index), 'ask_volume'] = ask_merge_update['ask_volume_y']
        # insert
        if ask_merge_insert.__len__() > 0:
            ask_merge_insert = ask_merge_insert[['ask_price', 'ask_volume_y', 'ask_qp_y', 'ask_n_y']]
            ask_merge_insert = ask_merge_insert.rename(index=str,
                                                       columns={'ask_volume_y': 'ask_volume', 'ask_qp_y': 'ask_qp',
                                                                'ask_n_y': 'ask_n'})
            ask = ask.append(ask_merge_insert)

        ask = ask.sort_values('ask_price').iloc[-200:].reset_index().drop('index', axis=1)

        bid_merge = bid.merge(bid_new, on='bid_price', right_index=True, how='right')
        bid_merge_update = bid_merge.dropna()
        bid_merge_delete = bid_merge[bid_merge['bid_volume_y'] == 0]
        bid_merge_update = bid_merge_update[bid_merge_update['bid_volume_y'] > 0]
        bid_merge_insert = bid_merge.append(bid_merge_update).drop_duplicates(keep=False)
        bid_merge_insert = bid_merge_insert[bid_merge_insert['bid_volume_y'] > 0]
        # delete
        if bid_merge_delete.__len__() > 0:
            bid = bid.drop(bid_merge_delete.index)
        # update
        if bid_merge_update.__len__() > 0:
            bid.loc[bid.index.isin(bid_merge_update.index), 'bid_volume'] = bid_merge_update['bid_volume_y']
        # insert
        if bid_merge_insert.__len__() > 0:
            bid_merge_insert = bid_merge_insert[['bid_price', 'bid_volume_y', 'bid_qp_y', 'bid_n_y']]
            bid_merge_insert = bid_merge_insert.rename(index=str,
                                                       columns={'bid_volume_y': 'bid_volume', 'bid_qp_y': 'bid_qp',
                                                                'bid_n_y': 'bid_n'}).dropna(axis=1)
            bid = bid.append(bid_merge_insert)

        bid = bid.sort_values('bid_price').iloc[-200:].reset_index().drop('index', axis=1)
        return ask, bid

    def send_data(self, ask, bid, time):
        self.queue.put({'ask':ask, 'bid':bid, 'time':time})
        # ask_huge = ask[ask['ask_price'] * ask['ask_volume'] >= self.limit]
        # bid_huge = bid[bid['bid_price'] * bid['bid_volume'] >= self.limit]
        # if ask_huge is not None and ask_huge.__len__() > 0:
        #     self.queue.put({'type': 'ask', 'data': ask_huge, 'time': time})
        #     # print(f'{time} 卖方大单  价格： {ask_huge.iloc[0,0]} 量：{ask_huge.iloc[0,0]} 档数：{ask_huge.index[0]}')
        #
        # if bid_huge is not None and bid_huge.__len__() > 0:
        #     self.queue.put({'type': 'bid', 'data': bid_huge, 'time': time})
        #     # print(f'{time} 买方大单 价格： {bid_huge.iloc[0,0]} 量： {bid_huge.iloc[0,1]} 档数：{bid_huge.index[0]}')
        # if ask_huge is None or ask_huge.__len__() == 0:
        #     self.queue.put({'type': 'ask_depth', 'data': ask, 'time': time})
        #
        # if bid_huge is None or bid_huge.__len__() == 0:
        #     self.queue.put({'type': 'bid_depth', 'data': bid, 'time': time})

    def get_server_time(self):
        url = "http://www.okex.com/api/general/v3/time"
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()['iso']
        else:
            return ""

    def server_timestamp(self):
        server_time = self.get_server_time()
        parsed_t = dp.parse(server_time)
        timestamp = parsed_t.timestamp()
        return timestamp

    def login_params(self, timestamp):
        message = timestamp + 'GET' + '/users/self/verify'
        mac = hmac.new(bytes(self.secret_key, encoding='utf8'), bytes(message, encoding='utf-8'), digestmod='sha256')
        d = mac.digest()
        sign = base64.b64encode(d)

        login_param = {"op": "login", "args": [self.api_key, self.passphrase, timestamp, sign.decode("utf-8")]}
        login_str = json.dumps(login_param)
        return login_str

    def inflate(self, data):
        decompress = zlib.decompressobj(
            -zlib.MAX_WBITS  # see above
        )
        inflated = decompress.decompress(data)
        inflated += decompress.flush()
        return inflated


if __name__ == '__main__':
    setting = {
        'symbol': 'EOS-USD-190927',
        'api_key': '0ec59551-1aab-4070-b55f-dbbb5c2372ad',
        'secret_key': '5118C891F3CD294B1E934D2E7ED26C5E',
        'passphrase': 'zhang123',
        'limit': 500000,
        'tick_bias': 1,
        'leverage': 20,
    }
    depth = Strategy(**setting)
    depth.test_order_delay()
    # depth.start()
    # res = depth.close_order(PositionDirection.long.value)
    # account = depth.send_order(OrderDirection.open_long.value, 5, 1,leverage=depth.leverage)
    # res = depth.cancel_order('3029177344670720')
    # print(res)
    # depth.start_tick()
