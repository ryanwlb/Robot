from strategy.big_order import BigOrder
from PyQt5.QtWidgets import  QHBoxLayout, QVBoxLayout, QApplication, QWidget, QPushButton, QLabel,QLineEdit,QGroupBox,QListWidget,QListWidgetItem,QCheckBox,QDateTimeEdit
from PyQt5.QtGui import QIcon,QPixmap,QFont
import PyQt5.QtCore as QtCore
import queue
import time
import datetime
import sys

def catch_exceptions(t, val, tb):
    print(t,val,tb)
    old_hook(t, val, tb)

old_hook = sys.excepthook
sys.excepthook = catch_exceptions


class workThread(QtCore.QThread):
    logSignal = QtCore.pyqtSignal(dict)

    def __init__(self, strategy):
        super(workThread,self).__init__()
        self.strategy = strategy
        self.printLog('软件启动!')

    def run(self):
        self.work()

    def work(self):

        self.printLog('软件启动!')
        self.strategy.start()

        self.printLog('软件结束!')

    def printLog(self,str):
        self.logSignal.emit({'msg':str})


class OWO(QWidget):
    def __init__(self,strategy):
        super(QWidget,self).__init__()
        self.strategy = strategy

        vBox = QVBoxLayout()

        logG=QGroupBox()
        logG.setTitle('信息')
        hBox=QHBoxLayout()
        self.logList=QListWidget()
        hBox.addWidget(self.logList)
        logG.setLayout(hBox)

        submitBtn=QPushButton('  提交  ')
        submitBtn.clicked.connect(self.submitFn)

        vBox.addWidget(logG)

        hBox7=QHBoxLayout()
        self.startBtn=QPushButton('  运行  ')
        self.startBtn.clicked.connect(self.startBtnClick)
        self.stopBtn=QPushButton('  停止  ')
        self.stopBtn.clicked.connect(self.stopBtnClick)
        mylable8=QLabel('作者：JadenGu0 RyanJC')
        font=QFont('微软雅黑')
        font.setPixelSize(18)
        mylable8.setFont(font)
        mylable8.setStyleSheet("""
            QLabel{color:#FF0000}
        """)
        hBox7.addWidget(self.startBtn)
        hBox7.addStretch()
        hBox7.addWidget(mylable8)
        hBox7.addStretch()
        hBox7.addWidget(self.stopBtn)

        vBox.addLayout(hBox7)
        self.stopBtn.setEnabled(False)

        icon=QIcon()
        icon.addPixmap(QPixmap('./JC.ico'),QIcon.Normal)
        self.setWindowIcon(icon)
        self.setLayout(vBox)
        self.setWindowTitle('高频机器人')
        self.resize(700,500)
        self.show()

    def submitFn(self,click):
        self.sendIni()

    def printLog(self,dic):
        item=QListWidgetItem(dic['msg'])
        self.logList.addItem(item)
        self.logList.setCurrentRow(self.logList.count()-1)
        if self.logList.count()>1000:
            item=self.logList.takeItem(0)
            del item

    def startBtnClick(self,click):
        self.startBtn.setEnabled(False)
        self.stopBtn.setEnabled(True)
        self.runWorkTh()

    def runWorkTh(self):

        self.myTh = workThread(self.strategy)
        self.myTh.logSignal.connect(self.printLog)
        self.myTh.start()

    def stopBtnClick(self,click=None):

        self.startBtn.setEnabled(True)
        self.stopBtn.setEnabled(False)

        self.printLog({'msg':'正在关闭软件'})

    def closeEvent(self, QCloseEvent):

        sys.exit(app.exec_())



if __name__=='__main__':

    setting = {
        'symbol': 'EOS-USD-190927',
        'api_key': '0ec59551-1aab-4070-b55f-dbbb5c2372ad',
        'secret_key': '5118C891F3CD294B1E934D2E7ED26C5E',
        'passphrase': 'zhang123',
        'limit': 500000,
        'tick_bias': 1,
        'leverage': 20,
        'dalay': 2,
        'lot': 1,
        'stoploss': 0.05, # 止损百分比
        'start_trailing_profit': 0.08, #开始移动止损盈利百分比
        'trailing_step': 0.7, # 最大收益的回撤 最大收益百分比的
        'percentage': 0.7, # 大单单量被吃了70%平仓
        'facevalue': 10
    }
    strategy = BigOrder(**setting)
    app=QApplication(sys.argv)
    owo=OWO(strategy=strategy)
    sys.exit(app.exec_())
